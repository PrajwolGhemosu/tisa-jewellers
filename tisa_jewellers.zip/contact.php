<?php

$host='localhost';
$user='root';
$database='tisajewellers';
$port=3306;
$connection=mysqli_connect($host,$user,"",$database,$port);

if(!$connection)
{
    die("mysqli unable to connect".mysqli_error());

}

if(isset($_POST['submit']))

{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    $query = "INSERT INTO `contact`(`sn`,`name`,`email`,`phone`,`message`)
            VALUES(NULL,'$name','$email','$phone','$message')";
    mysqli_query($connection, $query);
}
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Tisa Jewellers</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Bootstrap styles -->
    <link href="assets/css/first.css" rel="stylesheet"/>
    <!-- Customize styles -->
    <link href="style.css" rel="stylesheet"/>
    <!-- font awesome styles -->
	<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
		<!--[if IE 7]>
			<link href="css/font-awesome-ie7.min.css" rel="stylesheet">
		<![endif]-->

		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

	<!-- Favicons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
  </head>
<body>


<!--
Lower Header Section 
-->
<div class="container">
<div id="gototop"> </div>
<header id="header">
<div class="row">
	<div class="span4">
	<h1>
	<a class="logo" href="index.html"><span></span>
		<img src="assets/img/logo.jpg" alt="">
	</a>
	</h1>
	</div>

</div>
</header>

<!--
Navigation Bar Section 
-->
<div class="navbar">
	  <div class="navbar-inner">
		<div class="container">
		  <a data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </a>
		  <div class="nav-collapse">
			<ul class="nav">
			  <li class=""><a href="index.html">Home	</a></li>
			  <li class=""><a href="list-view.html">List View</a></li>
			  <li class=""><a href="grid-view.html">Grid View</a></li>
			  <li class=""><a href="three-col.html">Three Column View</a></li>
			  <li class=""><a href="four-col.html">Four Column View</a></li>
				<li class="active"><a href="contact.php">Contact Us</a></li>
			</ul>

		  </div>
		</div>
	  </div>
	</div>
<!-- 
Body Section 
-->
	<hr class="soften">
	<div class="well well-small">
	<h1></h1>
	<hr class="soften"/>	
	<div class="row-fluid">
		<div class="span8 relative">
		<iframe style="width:100%; height:350px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="assets/img/store.jpg"></iframe>

		<div class="absoluteBlk">
		<div class="well wellsmall">
		<h4>Contact Details</h4>
		<h5>
			New Road<br/>
			Kathmandu, Nepal<br/><br/>
			 
			<a href="#">info@tisajewellers.com</a><br/>
			﻿Mobile no: 9843-123456<br/>
			<a href="#">web:www.tisajewllers.com</a>
		</h5>
		</div>
		</div>
		</div>
		
		<div class="span4">
		<h4>Email Us</h4>
		<form class="form-horizontal" method="post" action="#">
        <fieldset>
          <div class="control-group">
           
              <input type="text" placeholder="name" name="name" class="input-xlarge"/>
           
          </div>
		   <div class="control-group">
           
              <input type="text" placeholder="email" name="email" class="input-xlarge"/>
           
          </div>
		   <div class="control-group">
           
              <input type="text" placeholder="phone number" name="phone" class="input-xlarge"/>
          
          </div>
          <div class="control-group">
              <textarea rows="3" id="textarea" placeholder="message" name="message"class="input-xlarge"></textarea>
           
          </div>

            <button class="shopBtn" type="submit" name="submit">Send email</button>

        </fieldset>
      </form>
		</div>
	</div>

	
</div>
<!-- 
Clients 
-->
<section class="our_client">
	<hr class="soften"/>
	<h4 class="title cntr"><span class="text">Manufactures</span></h4>
	<hr class="soften"/>
	<div class="row">
		<div class="span2">
			<a href="#"><img alt="" src="assets/img/1.png"></a>
		</div>
		<div class="span2">
			<a href="#"><img alt="" src="assets/img/2.png"></a>
		</div>
		<div class="span2">
			<a href="#"><img alt="" src="assets/img/3.png"></a>
		</div>
		<div class="span2">
			<a href="#"><img alt="" src="assets/img/4.png"></a>
		</div>
		<div class="span2">
			<a href="#"><img alt="" src="assets/img/5.png"></a>
		</div>
		<div class="span2">
			<a href="#"><img alt="" src="assets/img/6.png"></a>
		</div>
	</div>
</section>

<!--
Footer
-->
<footer class="footer">
<div class="row-fluid">
	<div class="span2">
	</div>

	<div class="span2">
		<h5>DESIGNERS</h5>
		PRAMILA SAKHA<br>
		ROSHNI LIGAL<br>
		ROJINA HENGAJU<br>
		ROJINA GORKHALI<br>
	</div>
	<div class="span2">
		<h5>About us</h5>
		We are just students of KHEC and this is something releated to our lessons hope you liked our project.
	</div>

	<div class="span2">
		<h5>Contact Us</h5>
		New Road Kathmandu, Nepal<br/>
		<a href="#">info@tisajewellers.com</a><br/>
		﻿Mob no: 9843-123456<br/>
		<a href="#">web:www.tisajewellers.com</a>
	</div>
 </div>
</footer>
</div><!-- /container -->


<a href="#" class="gotop"><i class="icon-double-angle-up"></i></a>
<!-- Placed at the end of the document so the pages load faster -->
<script src="assets/js/jquery.js"></script>
<script src="assets/js/first.min.js"></script>
<script src="assets/js/jquery.easing-1.3.min.js"></script>
<script src="assets/js/jquery.scrollTo-1.4.3.1-min.js"></script>
<script src="assets/js/shop.js"></script>
  </body>
</html>
